package com.binome02.wsprojet.service;

import com.binome02.wsprojet.entity.Livre;
import com.binome02.wsprojet.repository.LivreRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LivreService {
    private final LivreRepository livreRepository;

    public LivreService(LivreRepository livreRepository) {
        this.livreRepository = livreRepository;
    }
    public List<Livre> getAllLivres(){
        return livreRepository.findAll();
    }

    public Optional<Livre> getLivreById(Long id) {
        return livreRepository.findById(id);
    }
    public List<Livre> getLivreDisponibles(){
        return livreRepository.findByDisponibleTrue();
    }

}
