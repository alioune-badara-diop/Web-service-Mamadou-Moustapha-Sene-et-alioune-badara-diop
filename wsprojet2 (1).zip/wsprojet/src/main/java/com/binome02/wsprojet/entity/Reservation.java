package com.binome02.wsprojet.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity @AllArgsConstructor @NoArgsConstructor @Data
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nomUtilisateur;
    @ManyToOne
    private Livre livre;
    private LocalDate dateDebut;
    private LocalDate dateFin;
}
