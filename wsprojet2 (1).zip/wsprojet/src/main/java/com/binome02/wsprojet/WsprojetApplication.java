package com.binome02.wsprojet;

import com.binome02.wsprojet.entity.Livre;
import com.binome02.wsprojet.repository.LivreRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class WsprojetApplication {

	public static void main(String[] args) {
		SpringApplication.run(WsprojetApplication.class, args);
	}
	@Bean
	public CommandLineRunner demo(LivreRepository livreRepository) {
		return (args) -> {
			livreRepository.save(new Livre(null,"Spring Framework","Rod Johnson", true));
			// Insérer quelques livres par défaut dans la base

			livreRepository.save(new Livre(null,"Java Concurrency in Practice", "Brian Goetz", true));
			livreRepository.save(new Livre(null,"Design Patterns: Elements of Reusable Object-Oriented Software", "Erich Gamma", false));
			livreRepository.save(new Livre(null,"Clean Code", "Robert C. Martin", true));
		};
	}

}
