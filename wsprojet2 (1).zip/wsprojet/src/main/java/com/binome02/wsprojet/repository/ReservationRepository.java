package com.binome02.wsprojet.repository;

import com.binome02.wsprojet.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationRepository extends JpaRepository<Reservation,Long> {
}
