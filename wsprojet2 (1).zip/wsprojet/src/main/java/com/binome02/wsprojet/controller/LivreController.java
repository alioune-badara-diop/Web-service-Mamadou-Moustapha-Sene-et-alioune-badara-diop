package com.binome02.wsprojet.controller;


import com.binome02.wsprojet.entity.Livre;
import com.binome02.wsprojet.service.LivreService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/livres")
public class LivreController {
    private final LivreService livreService;
    public LivreController(LivreService livreService){
        this.livreService = livreService;
    }

    @GetMapping
    public List<Livre> getAllLivre(){
        return livreService.getAllLivres();
    }
   @GetMapping("/{id}")
    public Livre getLivreById(@PathVariable Long id) {
        return livreService.getLivreById(id).orElse(null);
    }

    @GetMapping("/disponibles")
    public List<Livre> getLivresDisponibles() {
        return livreService.getLivreDisponibles();
    }


    }
