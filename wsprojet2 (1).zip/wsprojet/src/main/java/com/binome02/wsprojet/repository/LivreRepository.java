package com.binome02.wsprojet.repository;

import com.binome02.wsprojet.entity.Livre;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LivreRepository extends JpaRepository<Livre,Long> {

    List<Livre> findByDisponibleTrue();
}
