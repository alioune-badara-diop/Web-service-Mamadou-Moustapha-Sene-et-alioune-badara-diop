package com.binome02.wsprojet.service;

import com.binome02.wsprojet.entity.Livre;
import com.binome02.wsprojet.entity.Reservation;
import com.binome02.wsprojet.repository.LivreRepository;
import com.binome02.wsprojet.repository.ReservationRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Optional;
@Service

public class ReservationService {

    private final ReservationRepository reservationRepository;

    private final LivreRepository livreRepository;

    public ReservationService(ReservationRepository reservationRepository, LivreRepository livreRepository) {
        this.reservationRepository = reservationRepository;
        this.livreRepository = livreRepository;
    }

    public Optional<Reservation> getReservationById(Long id) {
        return reservationRepository.findById(id);
    }

    public Reservation reservation(Long livreId, String nomUtilisateur, LocalDate dateDebut, LocalDate dateFin) throws Exception {

        Livre livre = livreRepository.findById(livreId).orElseThrow(() -> new Exception("Livre introuvable"));
        if (!livre.isDisponible()) {
            throw new Exception(("Livre non disponible"));
        }
        livre.setDisponible(false);
        livreRepository.save(livre);

        Reservation reservation = new Reservation();
        reservation.setLivre(livre);
        reservation.setNomUtilisateur(nomUtilisateur);
        reservation.setDateDebut(dateDebut);
        reservation.setDateFin(dateFin);
        return reservationRepository.save(reservation);
    }
    }


