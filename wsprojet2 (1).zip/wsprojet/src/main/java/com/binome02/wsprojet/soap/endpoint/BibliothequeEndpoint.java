package com.binome02.wsprojet.soap.endpoint;

import com.binome02.wsprojet.soap.model.*;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class BibliothequeEndpoint {

    private static final String NAMESPACE_URI = "http://example.com/wsprojet/soap";

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "AjouterLivreRequest")
    @ResponsePayload
    public AjouterLivreResponse ajouterLivre(@RequestPayload AjouterLivreRequest request) {
        AjouterLivreResponse response = new AjouterLivreResponse();
        response.setMessage("Livre ajouté : " + request.getTitre() + " par " + request.getAuteur());
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "ModifierLivreRequest")
    @ResponsePayload
    public ModifierLivreResponse modifierLivre(@RequestPayload ModifierLivreRequest request) {
        ModifierLivreResponse response = new ModifierLivreResponse();
        response.setMessage("Livre modifié ID=" + request.getLivreID());
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "SupprimerLivreRequest")
    @ResponsePayload
    public SupprimerLivreResponse supprimerLivre(@RequestPayload SupprimerLivreRequest request) {
        SupprimerLivreResponse response = new SupprimerLivreResponse();
        response.setMessage("Livre supprimé ID=" + request.getLivreID());
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "PreterLivreRequest")
    @ResponsePayload
    public PreterLivreResponse preterLivre(@RequestPayload PreterLivreRequest request) {
        PreterLivreResponse response = new PreterLivreResponse();
        response.setSuccess(true);
        response.setMessage("Livre prêté à l'utilisateur ID=" + request.getUserID());
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "RetournerLivreRequest")
    @ResponsePayload
    public RetournerLivreResponse retournerLivre(@RequestPayload RetournerLivreRequest request) {
        RetournerLivreResponse response = new RetournerLivreResponse();
        response.setSuccess(true);
        response.setMessage("Livre retourné par l'utilisateur ID=" + request.getUserID());
        return response;
    }
}

