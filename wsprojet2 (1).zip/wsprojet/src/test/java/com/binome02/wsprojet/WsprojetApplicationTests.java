package com.binome02.wsprojet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsprojetApplicationTests {

	@Test
	void contextLoads() {
	}

}
